<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <!--<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">-->
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="ConstruPre" />
    <meta name="copyright" content="Construcciones Prefabricadas" />
    <meta name="robots" content="index,follow" /> <meta name="revisit-after" content="5 days" />
    
    <meta name="description" content="Somos una empresa 100% salvadoreña con más de 21 años de experiencia en el mercado del prefabricado teniendo como bases sólidas los valores cristianos. Nos dedicamos a la fabricación, diseño y construcción de tapiales, casas prefabricadas y cualquier otro proyecto de construcción que usted nos confíe en desarrollar." />
    <meta name="keywords" content="Casas Hermosas, Prefabricados, Pisos, Casas Prefabricadas, Tapiales, Muros Perimetrales, Perimetros, casas colonos, Casas Finca, Casa en la Playa, El Salvador, Construcción, Diseño, Facilidad, Experiencia, Casas, Ranchos, Colonos, Tapiales Prefabricados, Techos, Tapiales de concreto, prefabricados" />
    
        <title>Casas Prefabricadas con hermosos acabados, dise�os excelentes, tapiales y muros, otras construcciones</title>
        
    
    <link rel="shortcut icon" type="image/x-icon" href="/images/home/construp.ico">
    <link rel="shortcut icon" href="/images/home/construp.ico">
    
    <link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Roboto:700,300' >
    <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="includes/bootstrap4/css/bootstrap.min.css">
    
    
    
    <link rel='stylesheet' type='text/css' href="/includes/global_new.css" />
            <link  rel='stylesheet' type='text/css' href="includes/proyectos.css"  />
                
    <!-- Slider -->
    <link rel="stylesheet" type="text/css" href="/includes/jquery.bxslider/jquery.bxslider.css" />
    <script type="text/javascript">
    /*
      var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-298471-3']);
      _gaq.push(['_trackPageview']);
    
      (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
    */
    </script>
    
    <!-- Global site tag (gtag.js) - Google Analytics: Añadido el 6 sept 2022-->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-158877144-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-158877144-1');
    </script>


</head>

<body>
<div id="global">

    <div id="top">
    	<div class="container">
            
            <nav class="navbar navbar-expand-lg navbar-light" >
            <a class="navbar-brand" href="/">
            <img src="images/logo_construcciones_prefabricadas.png" width="200"  class="d-inline-block align-top" alt="">
            
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse " id="navbarNav">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item ">
                <a class="nav-link" href="/">Inicio <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="/proyectos.php">Proyectos</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/servicios.php">Servicios</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/compania.php">Compa&ntilde;&iacute;a</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/contactenos.php">Cont&aacute;ctenos</a>
              </li>
              
              <li class="nav-item" id="facebook-menu">
                	
				
				    <a href="https://wa.me/50322886011" target="_blank" style="padding-left:8px;">
				    <img src="images/whatsapp.png" alt="WhatsApp ConstruPrefabricadas" name="WhatsApp" width="48" border="0"/></a>
				    
				    <a href="http://www.facebook.com/pages/Construcciones-Prefabricadas/157467160938184" target="_blank">
				    <img src="images/facebook-circle.png" alt="Facebook" name="facebook" width="40" height="40" border="0"/></a>
              </li>
              
            </ul>
            </div>
            </nav>
          </div><!-- container-->  
            
	</div><!-- FIN DEL DIV TOP !-->

    <div id="contenido" ><div class="container">
	<div class="row "> 
		<div class="col-12">
            <h1  class="titulos">Proyectos</h1>
            <p>Estos son algunos proyectos que hemos desarrollado para diferentes clientes, todo ha sido aplicando la mejor disposicion y la mayor personalizacion posible. Pronto estaremos publicando otros proyectos m&aacute;s recientes. Si le gusta lo que ve aqu&iacute;, por favor no deje de <a href="contactenos.php">contactarnos</a>.</p>
        </div>
        
                
                <div class="col-4 col-sm-6 col-lg-4 text-center" >
        	<div class="catItem">
                <a href="proyectoslist.php?id=4" title="Proyectos de Casas con acabados">
                    <div class="imagen"><img src="/images/show/categoria_288797329.jpg" border="0" alt="Proyectos de Casas con acabados" />
                    </div>
            	   <p>Casas con acabados</p>
                </a>
       	 	</div>
        </div>
                <div class="col-4 col-sm-6 col-lg-4 text-center" >
        	<div class="catItem">
                <a href="proyectoslist.php?id=21" title="Proyectos de Madera">
                    <div class="imagen"><img src="/images/show/categoria_368839292.jpg" border="0" alt="Proyectos de Madera" />
                    </div>
            	   <p>Madera</p>
                </a>
       	 	</div>
        </div>
                <div class="col-4 col-sm-6 col-lg-4 text-center" >
        	<div class="catItem">
                <a href="proyectoslist.php?id=22" title="Proyectos de Trabajos en bloques">
                    <div class="imagen"><img src="/images/show/categoria_713392583.php" border="0" alt="Proyectos de Trabajos en bloques" />
                    </div>
            	   <p>Trabajos en bloques</p>
                </a>
       	 	</div>
        </div>
                <div class="col-4 col-sm-6 col-lg-4 text-center" >
        	<div class="catItem">
                <a href="proyectoslist.php?id=3" title="Proyectos de Ranchos ">
                    <div class="imagen"><img src="/images/show/categoria_295794091.jpg" border="0" alt="Proyectos de Ranchos " />
                    </div>
            	   <p>Ranchos </p>
                </a>
       	 	</div>
        </div>
                <div class="col-4 col-sm-6 col-lg-4 text-center" >
        	<div class="catItem">
                <a href="proyectoslist.php?id=2" title="Proyectos de Casas B&aacute;sicas">
                    <div class="imagen"><img src="/images/show/categoria_1185233330.jpeg" border="0" alt="Proyectos de Casas B&aacute;sicas" />
                    </div>
            	   <p>Casas B&aacute;sicas</p>
                </a>
       	 	</div>
        </div>
                <div class="col-4 col-sm-6 col-lg-4 text-center" >
        	<div class="catItem">
                <a href="proyectoslist.php?id=1" title="Proyectos de Tapiales ">
                    <div class="imagen"><img src="/images/show/categoria_1438394108.jpg" border="0" alt="Proyectos de Tapiales " />
                    </div>
            	   <p>Tapiales </p>
                </a>
       	 	</div>
        </div>
        
   </div><!-- row -->
</div><!-- container-->

	
</div><!-- FIN DEL DIV DE CONTENIDO !-->
</div><!-- FIN DEL DIV GLOBAL !-->

<div id="pie"> 

	<div class="container">
    
    	<div class="row">
        	<div class="col-12 col-lg-4 justify-content-sm-center ">
            	&copy; Construcciones Prefabricadas. 
                <br />Construimos casas, ranchos, piscinas, tapiales y m&aacute;s.
                <br>Tel&eacute;fono: (503) 2228-0022<br />
                
            </div>
            
            <div class="col-12 col-lg-4">
            	  <ul>
                  <li><a href="/compania.php">Compa&ntilde;&iacute;a </a></li>
                  <li><a href="/servicios.php">Servicios</a></li>
                  <li><a href="/proyectos.php">Proyectos</a></li>
                  <li><a href="/contactenos.php">Cont&aacute;ctenos</a></li>
                  </ul>
            </div>
            
            <div class="justify-content-sm-left col-sm-12 col-lg-4 text-right ">
            	<!--
            	<a href="http://www.facebook.com/pages/Construcciones-Prefabricadas/157467160938184" target="_blank">
				<img src="images/siguenos.png" alt="Facebook" name="facebook" width="123" height="35" border="0"/></a>
				
				<a href="https://wa.me/50322886011" target="_blank" style="padding-left:16px;">
				<img src="images/whatsapp.png" alt="WhatsApp ConstruPrefabricadas" name="WhatsApp" width="48" border="0"/></a>
				-->
				
            </div>
        </div>
        

        <div class="row">
            <div class="col-sm-12">
            	<div id="powerby">
                    Dise&ntilde;o por <a href="http://www.oswosmedia.com" style="color:white;" target="_blank">Oswosmedia.com</a>
              	</div>
            </div>
        </div>

    </div>
</div>

<!--<script src="https://code.jquery.com/jquery-2.0.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>-->
<script src="includes/jquery-1.12.4.min.js"></script>
<script src="includes/bootstrap4/js/bootstrap.min.js"></script>

<script src="/includes/jquery.bxslider/jquery.bxslider.min.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function(){
		
		$('#slider').bxSlider({
			mode: 'horizontal',
			pager: true,
			autoStart:true, touchEnabled:true,
			pause:4500, speed: 1500,
			preloadImages: 'all',
			controls: true,
			auto:true,
			autoDelay:1500,
			autoHover: false,
			randomStart: false
		});
		
		
		$('.showvideo').on('click', function(event) {
			$('#hereVideo').show().load('boxVideo.html');
			event.preventDefault();
		});
	});
</script>
</body>
</html>