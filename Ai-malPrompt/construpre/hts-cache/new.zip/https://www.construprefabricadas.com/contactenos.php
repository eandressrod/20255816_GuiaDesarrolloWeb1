<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <!--<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">-->
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="ConstruPre" />
    <meta name="copyright" content="Construcciones Prefabricadas" />
    <meta name="robots" content="index,follow" /> <meta name="revisit-after" content="5 days" />
    
    <meta name="description" content="Somos una empresa 100% salvadoreña con más de 21 años de experiencia en el mercado del prefabricado teniendo como bases sólidas los valores cristianos. Nos dedicamos a la fabricación, diseño y construcción de tapiales, casas prefabricadas y cualquier otro proyecto de construcción que usted nos confíe en desarrollar." />
    <meta name="keywords" content="Casas Hermosas, Prefabricados, Pisos, Casas Prefabricadas, Tapiales, Muros Perimetrales, Perimetros, casas colonos, Casas Finca, Casa en la Playa, El Salvador, Construcción, Diseño, Facilidad, Experiencia, Casas, Ranchos, Colonos, Tapiales Prefabricados, Techos, Tapiales de concreto, prefabricados" />
    
        <title>Cont&aacute;cte a ConstruPrefabricadas, estamos para servirle en casas prefabricadas con hermosos acabados y excelentes dise�os </title>
        
    
    <link rel="shortcut icon" type="image/x-icon" href="/images/home/construp.ico">
    <link rel="shortcut icon" href="/images/home/construp.ico">
    
    <link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Roboto:700,300' >
    <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="includes/bootstrap4/css/bootstrap.min.css">
    
    
    
    <link rel='stylesheet' type='text/css' href="/includes/global_new.css" />
                    <link  rel='stylesheet' type='text/css' href="includes/contactenos.css" />
        
    <!-- Slider -->
    <link rel="stylesheet" type="text/css" href="/includes/jquery.bxslider/jquery.bxslider.css" />
    <script type="text/javascript">
    /*
      var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-298471-3']);
      _gaq.push(['_trackPageview']);
    
      (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
    */
    </script>
    
    <!-- Global site tag (gtag.js) - Google Analytics: Añadido el 6 sept 2022-->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-158877144-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-158877144-1');
    </script>


</head>

<body>
<div id="global">

    <div id="top">
    	<div class="container">
            
            <nav class="navbar navbar-expand-lg navbar-light" >
            <a class="navbar-brand" href="/">
            <img src="images/logo_construcciones_prefabricadas.png" width="200"  class="d-inline-block align-top" alt="">
            
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse " id="navbarNav">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item ">
                <a class="nav-link" href="/">Inicio <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/proyectos.php">Proyectos</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/servicios.php">Servicios</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/compania.php">Compa&ntilde;&iacute;a</a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="/contactenos.php">Cont&aacute;ctenos</a>
              </li>
              
              <li class="nav-item" id="facebook-menu">
                	
				
				    <a href="https://wa.me/50322886011" target="_blank" style="padding-left:8px;">
				    <img src="images/whatsapp.png" alt="WhatsApp ConstruPrefabricadas" name="WhatsApp" width="48" border="0"/></a>
				    
				    <a href="http://www.facebook.com/pages/Construcciones-Prefabricadas/157467160938184" target="_blank">
				    <img src="images/facebook-circle.png" alt="Facebook" name="facebook" width="40" height="40" border="0"/></a>
              </li>
              
            </ul>
            </div>
            </nav>
          </div><!-- container-->  
            
	</div><!-- FIN DEL DIV TOP !-->

    <div id="contenido" ><script Language="JavaScript1.2" type='text/javascript'>
function validarEmail(valor) {
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(valor)){
		return (true)
	} else {		
		return (false);
	}
}
function enviar(){				
	var MENSAJEDatosGenerales="Los siguientes son campos requeridos:\n\n";
	var indicadorError=0;
	var er_email = /^(.+\@.+\..+)$/
	var valida=true;
	if(document.frmAgregar.Mensaje.value == "" || document.frmAgregar.Mensaje.value=='Escriba su mensaje.'){
		MENSAJEDatosGenerales=MENSAJEDatosGenerales+"- Mensaje\n";
		indicadorError=1;
	}
	if(document.frmAgregar.Email.value == ""){
		MENSAJEDatosGenerales=MENSAJEDatosGenerales+"- Email\n";
		indicadorError=1;
	}else{
		if(!validarEmail(document.frmAgregar.Email.value) ){
		MENSAJEDatosGenerales=MENSAJEDatosGenerales+"- Formato del Email no v�lido\n";
		indicadorError=1;
		}
	}
	if(document.frmAgregar.Nombres.value == ""){
		MENSAJEDatosGenerales=MENSAJEDatosGenerales+"- Nombres\n";
		indicadorError=1;
	}
	if(document.frmAgregar.Lugar.value == ""){
		MENSAJEDatosGenerales=MENSAJEDatosGenerales+"- Lugar\n";
		indicadorError=1;
	}
	if(indicadorError==1){
		alert(MENSAJEDatosGenerales);
		valida=false;
		return false;
	}
	if(valida){
		return true;
	}
}
</script>

<div class="container">
	<div class="row">
       <div class="col-12 col-md-6" >
       		<h1 class="titulos">Cont&aacute;ctenos</h1>
            <p>Gracias por su inter&eacute;s en nuestros servicios, por favor escr&iacute;banos al e-mail o llenando el siguiente formulario.</p>
            
            <br style="clear:both;">
            <br /> * Que los campos son requeridos. <br /><br />
         
            <form action="contactenos.php" name="frmAgregar" id="frmAgregar" method="post" onsubmit="javascript:return enviar();">
            <input type="hidden" id="MM_insert" name="MM_insert" value="frmAgregar" />
            <div class="item">
            Nombre Completo: *<br />
            <input type="text" id="Nombres" name="Nombres" size="70" />
            </div>
            <div class="item">
            Email: *<br />
            <input type="text" id="Email" name="Email" size="70" />
            </div>
            <div class="item">
            Tel&eacute;fono:<br />
            <input type="text" id="Telefono" name="Telefono" size="70" />
            </div>
            <div class="item">
            Pa&iacute;s: *<br />
            <input type="text" id="Lugar" name="Lugar" size="70" placeholder="El Salvador" />
            </div>
            <div class="item">
            Mensaje: *<br />
            <textarea name="Mensaje" cols="57" rows="10" id="Mensaje"></textarea>
            </div>
            <div class="item">
            <input type="submit" value="Enviar Mensaje" class="boton"/>
            </div>
            
            
            
            </form>
           
           
           
       </div>   
	   
	   <div class="col-12 col-md-6">
       
       	<img src="images/bgcontactenos.gif" class="page-image shadow" alt="Nuestros servicios de construcci�n">
       
            <p><strong>Direcci&oacute;n Oficina:</strong><br>
            15 Av. Sur Blok &quot;D&quot; No. 14 Residencial Bethania, Santa Tecla.<br />
            La Libertad, El Salvador <br>
            <br>
            
            <strong>Direcci&oacute;n Planta: </strong><br>
            Km.29 Carretera a Sonsonate, Lotificaci&oacute;n El Ed&eacute;n, Lourdes Col&oacute;n. <br />
            La Libertad, El Salvador <br>
            <br>
            
            Tel&eacute;fono Oficina: <br>
            <strong>(503) 2228-0022</strong><br>
            
            </p>
	    </div>
      </div>
	  
</div>
      
	
</div><!-- FIN DEL DIV DE CONTENIDO !-->
</div><!-- FIN DEL DIV GLOBAL !-->

<div id="pie"> 

	<div class="container">
    
    	<div class="row">
        	<div class="col-12 col-lg-4 justify-content-sm-center ">
            	&copy; Construcciones Prefabricadas. 
                <br />Construimos casas, ranchos, piscinas, tapiales y m&aacute;s.
                <br>Tel&eacute;fono: (503) 2228-0022<br />
                
            </div>
            
            <div class="col-12 col-lg-4">
            	  <ul>
                  <li><a href="/compania.php">Compa&ntilde;&iacute;a </a></li>
                  <li><a href="/servicios.php">Servicios</a></li>
                  <li><a href="/proyectos.php">Proyectos</a></li>
                  <li><a href="/contactenos.php">Cont&aacute;ctenos</a></li>
                  </ul>
            </div>
            
            <div class="justify-content-sm-left col-sm-12 col-lg-4 text-right ">
            	<!--
            	<a href="http://www.facebook.com/pages/Construcciones-Prefabricadas/157467160938184" target="_blank">
				<img src="images/siguenos.png" alt="Facebook" name="facebook" width="123" height="35" border="0"/></a>
				
				<a href="https://wa.me/50322886011" target="_blank" style="padding-left:16px;">
				<img src="images/whatsapp.png" alt="WhatsApp ConstruPrefabricadas" name="WhatsApp" width="48" border="0"/></a>
				-->
				
            </div>
        </div>
        

        <div class="row">
            <div class="col-sm-12">
            	<div id="powerby">
                    Dise&ntilde;o por <a href="http://www.oswosmedia.com" style="color:white;" target="_blank">Oswosmedia.com</a>
              	</div>
            </div>
        </div>

    </div>
</div>

<!--<script src="https://code.jquery.com/jquery-2.0.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>-->
<script src="includes/jquery-1.12.4.min.js"></script>
<script src="includes/bootstrap4/js/bootstrap.min.js"></script>

<script src="/includes/jquery.bxslider/jquery.bxslider.min.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function(){
		
		$('#slider').bxSlider({
			mode: 'horizontal',
			pager: true,
			autoStart:true, touchEnabled:true,
			pause:4500, speed: 1500,
			preloadImages: 'all',
			controls: true,
			auto:true,
			autoDelay:1500,
			autoHover: false,
			randomStart: false
		});
		
		
		$('.showvideo').on('click', function(event) {
			$('#hereVideo').show().load('boxVideo.html');
			event.preventDefault();
		});
	});
</script>
</body>
</html>