<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <!--<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">-->
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="ConstruPre" />
    <meta name="copyright" content="Construcciones Prefabricadas" />
    <meta name="robots" content="index,follow" /> <meta name="revisit-after" content="5 days" />
    
    <meta name="description" content="Somos una empresa 100% salvadoreña con más de 21 años de experiencia en el mercado del prefabricado teniendo como bases sólidas los valores cristianos. Nos dedicamos a la fabricación, diseño y construcción de tapiales, casas prefabricadas y cualquier otro proyecto de construcción que usted nos confíe en desarrollar." />
    <meta name="keywords" content="Casas Hermosas, Prefabricados, Pisos, Casas Prefabricadas, Tapiales, Muros Perimetrales, Perimetros, casas colonos, Casas Finca, Casa en la Playa, El Salvador, Construcción, Diseño, Facilidad, Experiencia, Casas, Ranchos, Colonos, Tapiales Prefabricados, Techos, Tapiales de concreto, prefabricados" />
    
        <title>Casas prefabricadas con hermosos acabados y los mejores dise�os</title>
        
    
    <link rel="shortcut icon" type="image/x-icon" href="/images/home/construp.ico">
    <link rel="shortcut icon" href="/images/home/construp.ico">
    
    <link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Roboto:700,300' >
    <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="includes/bootstrap4/css/bootstrap.min.css">
    
    
    
    <link rel='stylesheet' type='text/css' href="/includes/global_new.css" />
        <link rel='stylesheet' type='text/css' href="includes/home_new.css?v=1.1" />
                    
    <!-- Slider -->
    <link rel="stylesheet" type="text/css" href="/includes/jquery.bxslider/jquery.bxslider.css" />
    <script type="text/javascript">
    /*
      var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-298471-3']);
      _gaq.push(['_trackPageview']);
    
      (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
      })();
    */
    </script>
    
    <!-- Global site tag (gtag.js) - Google Analytics: Añadido el 6 sept 2022-->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-158877144-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-158877144-1');
    </script>


</head>

<body>
<div id="global">

    <div id="top">
    	<div class="container">
            
            <nav class="navbar navbar-expand-lg navbar-light" >
            <a class="navbar-brand" href="/">
            <img src="images/logo_construcciones_prefabricadas.png" width="200"  class="d-inline-block align-top" alt="">
            
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse " id="navbarNav">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item active">
                <a class="nav-link" href="/">Inicio <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/proyectos.php">Proyectos</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/servicios.php">Servicios</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/compania.php">Compa&ntilde;&iacute;a</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/contactenos.php">Cont&aacute;ctenos</a>
              </li>
              
              <li class="nav-item" id="facebook-menu">
                	
				
				    <a href="https://wa.me/50322886011" target="_blank" style="padding-left:8px;">
				    <img src="images/whatsapp.png" alt="WhatsApp ConstruPrefabricadas" name="WhatsApp" width="48" border="0"/></a>
				    
				    <a href="http://www.facebook.com/pages/Construcciones-Prefabricadas/157467160938184" target="_blank">
				    <img src="images/facebook-circle.png" alt="Facebook" name="facebook" width="40" height="40" border="0"/></a>
              </li>
              
            </ul>
            </div>
            </nav>
          </div><!-- container-->  
            
	</div><!-- FIN DEL DIV TOP !-->

    <div id="contenido" >

        <div id="hereVideo"></div>
        

		<section id="sec_hola">
            <div class="container">
                <div class="row no-gutters">
                    <div id="anim" class="col-12 col-sm-12 col-md-9 ">
                                                                        <ul id="slider">
                                                        <li>
                                <div id="titulo"><a href="/proyecto.php?id=65">Portal de Las Orquídeas II </a></div>
                                <a href="proyecto.php?id=65" title="Portal de Las Orquídeas II ">
                                <img src="/images/show/304292814.jpg" alt="Portal de Las Orquídeas II " border="0"  />
                                </a>
                                
                             </li>
                                                        <li>
                                <div id="titulo"><a href="/proyecto.php?id=32">Sta.Elena, Usulután </a></div>
                                <a href="proyecto.php?id=32" title="Sta.Elena, Usulután ">
                                <img src="/images/show/825048937.jpg" alt="Sta.Elena, Usulután " border="0"  />
                                </a>
                                
                             </li>
                                                        <li>
                                <div id="titulo"><a href="/proyecto.php?id=114">Berlín </a></div>
                                <a href="proyecto.php?id=114" title="Berlín ">
                                <img src="/images/show/277888923.jpg" alt="Berlín " border="0"  />
                                </a>
                                
                             </li>
                                                        <li>
                                <div id="titulo"><a href="/proyecto.php?id=106">Perquín</a></div>
                                <a href="proyecto.php?id=106" title="Perquín">
                                <img src="/images/show/417984223.jpg" alt="Perquín" border="0"  />
                                </a>
                                
                             </li>
                                                        <li>
                                <div id="titulo"><a href="/proyecto.php?id=125">Apaneca II</a></div>
                                <a href="proyecto.php?id=125" title="Apaneca II">
                                <img src="/images/show/671416060.jpg" alt="Apaneca II" border="0"  />
                                </a>
                                
                             </li>
                                                    </ul>
                                            </div>
            
                    <div id="video-holder"  class="col-12 col-sm-3 col-md-3 ">
                        <a href="#showvideo" class="showvideo">
                        <h1>VIDEO:<br />Nuestro equipo construye una casa de concreto prefabricada en un d&Iacute;a</h1></a>					
                        <div class="video-image">	
                            <a href="#showvideo" class="showvideo">
                            <img src="images/anim/video_team.jpg" class="video-team" border="0" />
                            </a>
                            <div id="play">
                            	<a href="#showvideo" class="showvideo"><img src="images/anim/play.png" /></a>
                            </div>
                        </div>
                    </div>
               </div><!--end of row -->
           </div><!-- container-->
       </section>
       
       <section id="sec_tipos">
           <div class="container">
               <div class="row">
                    <div class="col-md-12">
                                                                        <div class="d-flex align-items-stretch justify-content-center align-self-center flex-wrap tipos">
                                                                <a href="/proyectoslist.php?id=2">Casas B&aacute;sicas</a>
                                                                <a href="/proyectoslist.php?id=4">Casas con acabados</a>
                                                                <a href="/proyectoslist.php?id=21">Madera</a>
                                                                <a href="/proyectoslist.php?id=3">Ranchos </a>
                                                                <a href="/proyectoslist.php?id=1">Tapiales </a>
                                                                <a href="/proyectoslist.php?id=22">Trabajos en bloques</a>
                                                        </div>
                                            </div>
                </div>
            </div>
        </section>
        
        
        
        <section id="sec_welcome">
            <div class="container">
            <div class="h-welcome blocked row">
                <div class="col-12 col-md-4">
                    <a href="/compania.php"><img id="imagen-ppal" src="images/anim/constructor.jpg" alt="Bienvenidos a ConstruPre" border="0" /></a>
                </div>
                
                <div class="col-12 col-md-6">
                    
                       <h2>CONSTRUPRE: SERVICIO, CALIDAD Y PROFESIONALISMO</h2>
                       <p>Gracias por su visita. Hemos publicado algunos proyectos que construimos, esperando que usted pueda tener una idea de lo que somos capaces de desarrollar para usted.</p>
                       <p><strong>M&aacute;s de 24 a&ntilde;os de experiencia.</strong></p>
                    
                </div>
            </div>
            </div><!-- container -->
        </section>
        
        <section id="sec_proyectos">
            <div class="container">
                <div class="h-proyectos blocked row">
                    
                    <div class="col-12 col-md-8 ">
                                                                            <h2>PROYECTOS REALIZADOS</h2>
                                <ul>
                                                                        <li>
                                        <div class="imagen bordered"><a href="proyecto.php?id=58"><img src="/images/thumb/1891533236.jpg" alt="Tapial Chalchuapa" border="0"  /></a></div>
                                        <h2><a href="proyecto.php?id=58">Tapial Chalchuapa</a></h2>
                                    </li>
                                                                        <li>
                                        <div class="imagen bordered"><a href="proyecto.php?id=9"><img src="/images/thumb/1505075086.jpg" alt="Finca Lutecia I " border="0"  /></a></div>
                                        <h2><a href="proyecto.php?id=9">Finca Lutecia I </a></h2>
                                    </li>
                                                                        <li>
                                        <div class="imagen bordered"><a href="proyecto.php?id=133"><img src="/images/thumb/123770264.jpg" alt=" Cara Sucia" border="0"  /></a></div>
                                        <h2><a href="proyecto.php?id=133"> Cara Sucia</a></h2>
                                    </li>
                                                                        <li>
                                        <div class="imagen bordered"><a href="proyecto.php?id=22"><img src="/images/thumb/903881479.jpg" alt="Apartamento Prefabricado " border="0"  /></a></div>
                                        <h2><a href="proyecto.php?id=22">Apartamento Prefabricado </a></h2>
                                    </li>
                                                                        <li>
                                        <div class="imagen bordered"><a href="proyecto.php?id=116"><img src="/images/thumb/1389959447.jpg" alt="Juayúa Brisas del Pinar III" border="0"  /></a></div>
                                        <h2><a href="proyecto.php?id=116">Juayúa Brisas del Pinar III</a></h2>
                                    </li>
                                                                        <li>
                                        <div class="imagen bordered"><a href="proyecto.php?id=43"><img src="/images/thumb/1602382373.jpg" alt="Lago de Coatepeque " border="0"  /></a></div>
                                        <h2><a href="proyecto.php?id=43">Lago de Coatepeque </a></h2>
                                    </li>
                                                                    </ul>
                                            </div>
                    <div class="col-12 col-md-4 text-right ">
                    <a href="/proyectos.php"><img id="imagen-ppal" src="images/anim/carretilla.jpg" alt="Proyectos realizados" border="0" /></a>
                    <p>Estos son algunos de los proyecto, usted puede ver un listado completo en este enlace:
                        <a href="proyectoslist.php?">Portafolio de proyectos</a></p>
                    </div>
                    
                </div>
            </div><!-- container-->
        </section>
      
       
</div><!-- FIN DEL DIV DE CONTENIDO !-->
</div><!-- FIN DEL DIV GLOBAL !-->

<div id="pie"> 

	<div class="container">
    
    	<div class="row">
        	<div class="col-12 col-lg-4 justify-content-sm-center ">
            	&copy; Construcciones Prefabricadas. 
                <br />Construimos casas, ranchos, piscinas, tapiales y m&aacute;s.
                <br>Tel&eacute;fono: (503) 2228-0022<br />
                
            </div>
            
            <div class="col-12 col-lg-4">
            	  <ul>
                  <li><a href="/compania.php">Compa&ntilde;&iacute;a </a></li>
                  <li><a href="/servicios.php">Servicios</a></li>
                  <li><a href="/proyectos.php">Proyectos</a></li>
                  <li><a href="/contactenos.php">Cont&aacute;ctenos</a></li>
                  </ul>
            </div>
            
            <div class="justify-content-sm-left col-sm-12 col-lg-4 text-right ">
            	<!--
            	<a href="http://www.facebook.com/pages/Construcciones-Prefabricadas/157467160938184" target="_blank">
				<img src="images/siguenos.png" alt="Facebook" name="facebook" width="123" height="35" border="0"/></a>
				
				<a href="https://wa.me/50322886011" target="_blank" style="padding-left:16px;">
				<img src="images/whatsapp.png" alt="WhatsApp ConstruPrefabricadas" name="WhatsApp" width="48" border="0"/></a>
				-->
				
            </div>
        </div>
        

        <div class="row">
            <div class="col-sm-12">
            	<div id="powerby">
                    Dise&ntilde;o por <a href="http://www.oswosmedia.com" style="color:white;" target="_blank">Oswosmedia.com</a>
              	</div>
            </div>
        </div>

    </div>
</div>

<!--<script src="https://code.jquery.com/jquery-2.0.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>-->
<script src="includes/jquery-1.12.4.min.js"></script>
<script src="includes/bootstrap4/js/bootstrap.min.js"></script>

<script src="/includes/jquery.bxslider/jquery.bxslider.min.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function(){
		
		$('#slider').bxSlider({
			mode: 'horizontal',
			pager: true,
			autoStart:true, touchEnabled:true,
			pause:4500, speed: 1500,
			preloadImages: 'all',
			controls: true,
			auto:true,
			autoDelay:1500,
			autoHover: false,
			randomStart: false
		});
		
		
		$('.showvideo').on('click', function(event) {
			$('#hereVideo').show().load('boxVideo.html');
			event.preventDefault();
		});
	});
</script>
</body>
</html>